%%
% This section is the initial analysis of the excel files.

% Import data from the CSV files into tables
Demand = readtable("Group10_demand_5years_irradiance.csv");
Supply = readtable("Group10_supply_5years_irradiance.csv");

% Accessing specific columns using corrected names
Demandtime = Demand.time_s_;
DemandpowerMW = Demand.power_kW_ / 1000; % Convert from kW to MW

Supplytime = Supply.time_s_;
PV_efficiency=0.15; %15% efficiency
SupplypowerMW = (Supply.power_kW_ / 1000) * PV_efficiency; % Convert from kW to MW

% Convert time to days, weeks, and months
days = floor(Demandtime / (24*60*60)); % seconds to days
weeks = floor(days / 7);               % days to weeks
months = floor(days / 30);             % rough approximation of months

% Get unique values
uniqueDays = unique(days);
uniqueWeeks = unique(weeks);
uniqueMonths = unique(months);

% Create a figure
figure;

% Plot the differences per month
subplot(3, 2, 6);


for i = 1:length(uniqueMonths)
    monthIndex = find(months == uniqueMonths(i));
    monthlyDemand = sum(DemandpowerMW(monthIndex));
    monthlySupply = sum(SupplypowerMW(monthIndex));
    monthlyDifference = monthlySupply - monthlyDemand;
    bar(uniqueMonths(i), monthlyDifference)
    hold on

    
end
hold off
xlabel('Month')
ylabel('Difference (MW)')
title('Difference between Supply and Demand per Month')

% Plot the differences per week
subplot(3, 2, 5);
for i = 1:length(uniqueWeeks)
    weekIndex = find(weeks == uniqueWeeks(i));
    weeklyDemand = sum(DemandpowerMW(weekIndex));
    weeklySupply = sum(SupplypowerMW(weekIndex));
    weeklyDifference = weeklySupply - weeklyDemand;
    bar(uniqueWeeks(i), weeklyDifference)
    hold on
end
hold off
xlabel('Week')
ylabel('Difference (MW)')
title('Difference between Supply and Demand per Week')

% Plot power vs. time overall
subplot(3, 2, [1,2]);
plot(Demandtime, DemandpowerMW, '-b')
hold on
plot(Supplytime, SupplypowerMW, '-r')
legend('Demand', 'Supply')
xlabel('Time (s)')
ylabel('Power (MW)')
title('Power vs. Time')
xlim([0, 86400]) % Show first day only

% Plot the power vs. time per day Demand
subplot(3, 2, 4);
for i = 1:length(uniqueDays)
    dayIndex = find(days == uniqueDays(i));
    dayStart = min(Demandtime(dayIndex));
    plot(Demandtime(dayIndex) - dayStart, DemandpowerMW(dayIndex))
    hold on
end
hold off
xlabel('Time (s)')
ylabel('Power (MW)')
title('Power vs. Time per Day - Demand')

% Plot the power vs. time per day Supply
subplot(3, 2, 3);
for i = 1:length(uniqueDays)
    dayIndex = find(days == uniqueDays(i));
    dayStart = min(Supplytime(dayIndex));
    plot(Supplytime(dayIndex) - dayStart, SupplypowerMW(dayIndex))
    hold on
end
hold off
xlabel('Time (s)')
ylabel('Power (MW)')
title('Power vs. Time per Day - Supply')

% Additional Figure, extra focus on: Monthly and Weekly Supply vs. Demand
figure;

% Monthly Supply and Demand
subplot(2, 1, 1); % Top plot
monthlyDemandVals = zeros(length(uniqueMonths), 1);
monthlySupplyVals = zeros(length(uniqueMonths), 1);

for i = 1:length(uniqueMonths)
    monthIndex = find(months == uniqueMonths(i));
    monthlyDemandVals(i) = sum(DemandpowerMW(monthIndex));
    monthlySupplyVals(i) = sum(SupplypowerMW(monthIndex));
end

bar(uniqueMonths, [monthlyDemandVals, monthlySupplyVals], 'grouped')
legend('Demand', 'Supply')
xlabel('Month')
ylabel('Total Power (MW)')
title('Monthly Total Demand and Supply')
grid on

% Weekly Supply and Demand
subplot(2, 1, 2); % Bottom plot
weeklyDemandVals = zeros(length(uniqueWeeks), 1);
weeklySupplyVals = zeros(length(uniqueWeeks), 1);

for i = 1:length(uniqueWeeks)
    weekIndex = find(weeks == uniqueWeeks(i));
    weeklyDemandVals(i) = sum(DemandpowerMW(weekIndex));
    weeklySupplyVals(i) = sum(SupplypowerMW(weekIndex));
end

bar(uniqueWeeks, [weeklyDemandVals, weeklySupplyVals], 'grouped')
legend('Demand', 'Supply')
xlabel('Week')
ylabel('Total Power (MW)')
title('Weekly Total Demand and Supply')
grid on



%% Energy Storage System Modular Simulation

% This section is the energy storage system 
% Simulation is hourly, the plots are monthly.

% Parameters
% Transformer efficiencies
stepUpEfficiency = 0.98;    % Step-up transformer (supply to storage)
stepDownEfficiency = 0.97;  % Step-down transformer (for injection)
stepUpAgainEfficiency = 0.98; % Step-up again for delivery to demand

dt = median(diff(Demandtime)) / 3600; % Time step in hours


%Part that sets multiple storage units
numUnits =1 ; % She said one composide unit with 3*10ft containers
containersPerUnit = 3;

storageCapacities = ones(numUnits, containersPerUnit) * (3.5 / containersPerUnit); %Capacity distributed across the containers in MW
storageStates = zeros(numUnits, containersPerUnit);
ATES_history = zeros(length(Demandtime), numUnits, containersPerUnit);


% Logging
injectedEnergyLog = zeros(length(Demandtime), 1);
extractedEnergyLog = zeros(length(Demandtime), 1);
supplyLossLog = zeros(length(Demandtime), 1);
injectionLossLog = zeros(length(Demandtime), 1);
extractionLossLog = zeros(length(Demandtime), 1);
deliveryLossLog = zeros(length(Demandtime), 1);

% Transformer loss logs
stepUpLossLog = zeros(length(Demandtime), 1);      
stepDownLossLog = zeros(length(Demandtime), 1);     
secondStepUpLossLog = zeros(length(Demandtime), 1); 


% Initialize the injection control flag and storage threshold
injectingAllowed = true;
storageThreshold = 3.5; % 3.5 MWh
soldEnergyLog = zeros(length(Demandtime), 1); % Initialize sold energy log

for t = 1:length(Demandtime)
    supplyPower = SupplypowerMW(t);
    demandPower = DemandpowerMW(t);

    % Step 0: Check total storage and adjust injection control
    totalStoredEnergy = sum(storageStates(:));

    if injectingAllowed && totalStoredEnergy >= storageThreshold
        injectingAllowed = false; % Stop injecting, start selling
    elseif ~injectingAllowed && totalStoredEnergy < storageThreshold
        injectingAllowed = true;  % Resume injecting
    end

    % Step 1: Transport from supply
    % Step-up transformer loss before transport
    steppedUpPower = supplyPower * stepUpEfficiency;
    [deliveredPower, powerLoss] = transport_from_supply(steppedUpPower);

    supplyLossLog(t) = powerLoss;

    % Step 2: Controller decides inject/extract per unit
    [injectFlags, extractFlags] = multi_controller(storageStates, storageCapacities, deliveredPower, demandPower);

    % Step 3: Injection or Selling
    injectedEnergy = zeros(numUnits, containersPerUnit);
    rawInjected = 0;
    totalInjectEff = 0;

    if injectingAllowed && any(injectFlags)
        excessPower = max(0, deliveredPower - demandPower);

    	% Apply step-down transformer efficiency before injection
        stepDownAdjustedPower = excessPower * stepDownEfficiency;

    % Inject this reduced power into the storage system
        totalInjectEff = injection(stepDownAdjustedPower, dt);
        rawInjected = excessPower * dt;

        

        availableSpace = storageCapacities - storageStates; % 1 x 3 vector
        totalAvailableSpace = sum(availableSpace);

        if totalAvailableSpace > 0
            injectedEnergy = zeros(1, containersPerUnit);
            injectedEnergy(injectFlags) = (availableSpace(injectFlags) / totalAvailableSpace) * totalInjectEff;
        else
            injectedEnergy = zeros(1, containersPerUnit);
        end

        injectionLossLog(t) = rawInjected - totalInjectEff;
    elseif ~injectingAllowed
    % Selling excess energy (no injection)
        excessPower = max(0, deliveredPower - demandPower);
        soldEnergyLog(t) = excessPower * dt;
        injectionLossLog(t) = 0;
    else
        injectionLossLog(t) = 0;
    end


    injectedEnergyLog(t) = sum(injectedEnergy(:));

    if any(extractFlags)
        shortfallPower = max(0, demandPower - deliveredPower); % power needed from storage
        totalExtractEff = extraction(shortfallPower, dt);      % effective energy extracted after efficiency loss
        rawExtracted = shortfallPower * dt;                    % raw energy requested from storage

        availableEnergy = storageStates;                        % 1 x 3 vector
        totalAvailableEnergy = sum(availableEnergy);

        extractedEnergy = zeros(1, containersPerUnit);

        if totalAvailableEnergy > 0
        % Only consider containers flagged for extraction
            flaggedAvailableEnergy = availableEnergy .* extractFlags;
            totalFlaggedEnergy = sum(flaggedAvailableEnergy);

            if totalFlaggedEnergy > 0
                % Distribute extracted energy proportionally among flagged containers
                extractedEnergy(extractFlags) = (flaggedAvailableEnergy(extractFlags) / totalFlaggedEnergy) * totalExtractEff;
            else
            % No energy available in flagged containers, no extraction
                extractedEnergy(:) = 0;
            end
        else
        % No energy available at all, no extraction
            extractedEnergy(:) = 0;
        end

        extractionLossLog(t) = rawExtracted - totalExtractEff;
    else
        extractedEnergy = zeros(1, containersPerUnit);
        extractionLossLog(t) = 0;
    end

    



    extractedEnergyLog(t) = sum(extractedEnergy(:));

    % Step 5: Update storage
    for i = 1:numUnits
        for j = 1:containersPerUnit
            storageStates(j) = storage(storageStates(j), injectedEnergy(j), extractedEnergy(j), storageCapacities(j));
            ATES_history(t, 1, j) = storageStates(j); % since one unit, index 1
        end

    end

    % Step 6: Transport to demand
     % Apply step-up again before transport to demand
    steppedUpEnergy = sum(extractedEnergy(:)) * stepUpAgainEfficiency;
    [deliveredEnergy, deliveryLoss] = transport_to_demand(steppedUpEnergy);

    deliveryLossLog(t) = deliveryLoss;
end

% Final summary line
totalSold = sum(soldEnergyLog);
fprintf('Total Energy Sold to Grid (Excess beyond 3.5 MWh): %.2f MWh\n', totalSold);


% Monthly grouping
months = floor(Demandtime / (30*24*3600));
uniqueMonths = unique(months);

monthlyInjected = accumarray(months + 1, injectedEnergyLog);
monthlyExtracted = accumarray(months + 1, extractedEnergyLog);
monthlySupplyLoss = accumarray(months + 1, supplyLossLog);
monthlyInjectionLoss = accumarray(months + 1, injectionLossLog);
monthlyExtractionLoss = accumarray(months + 1, extractionLossLog);
monthlyStorageLoss = monthlyInjectionLoss + monthlyExtractionLoss;

monthlyDeliveryLoss = accumarray(months + 1, deliveryLossLog);

figure;

subplot(3,1,1)
bar(uniqueMonths + 1, monthlyInjected, 'FaceColor', [0.2 0.7 1]);
hold on;
bar(uniqueMonths + 1, monthlyExtracted, 'FaceColor', [1 0.6 0.2]);
xlabel('Month');
ylabel('Energy (MWh)');
legend('Injected', 'Extracted');
title('Monthly Injected and Extracted Energy');
grid on;

subplot(3,1,2)
bar(uniqueMonths + 1, monthlyStorageLoss, 'FaceColor', [0.8 0.2 0.2]);
xlabel('Month');
ylabel('Loss (MWh)');
title('Monthly Storage Losses');
grid on;

subplot(3,1,3)
bar(uniqueMonths + 1, monthlySupplyLoss + monthlyDeliveryLoss, 'stacked');
legend('Supply Transport Loss', 'Demand Delivery Loss');
xlabel('Month');
ylabel('Loss (MWh)');
title('Monthly Transport Losses');
grid on;

% Monthly storage visualization
monthlyStorage = zeros(length(uniqueMonths), 1);
for i = 1:length(uniqueMonths)
    idx = find(months == uniqueMonths(i), 1, 'last');
    if ~isempty(idx)
        monthlyStorage(i) = ATES_history(idx);
        monthlyStorage(i) = sum(ATES_history(idx, 1, :), 3);  % sum over containers dimension

    end
end
totalStoragePerUnit = sum(storageStates, 2); % sum over containers

figure;
bar(uniqueMonths + 1, monthlyStorage, 'FaceColor', [0.2 0.6 0.3]);
xlabel('Month');
ylabel('Stored Energy (MWh)');
title('Storage Level at End of Each Month');
grid on;




% Efficiency Analysis
totalInjected = sum(injectedEnergyLog);
totalExtracted = sum(extractedEnergyLog);
totalSupplyLoss = sum(supplyLossLog);
totalInjectionLoss = sum(injectionLossLog);
totalExtractionLoss = sum(extractionLossLog);
totalStorageLoss = totalInjectionLoss + totalExtractionLoss;

% Transformer losses
totalStepUpLoss = sum(stepUpLossLog);             
totalStepDownLoss = sum(stepDownLossLog);         
totalSecondStepUpLoss = sum(secondStepUpLossLog);
totalTransformerLoss = totalStepUpLoss + totalStepDownLoss + totalSecondStepUpLoss;


totalDeliveryLoss = sum(deliveryLossLog);
totalLoss = totalSupplyLoss + totalStorageLoss + totalDeliveryLoss +totalTransformerLoss;


overallSystemEfficiency = totalExtracted / (totalInjected + totalLoss);



% Summary
fprintf('--- System Efficiency Summary ---\n');
fprintf('Total Energy Injected: %.2f MWh\n', totalInjected);
fprintf('Total Energy Extracted: %.2f MWh\n', totalExtracted);

fprintf('Overall System Efficiency (incl. losses): %.2f%%\n', 100 * overallSystemEfficiency);
fprintf('Total Energy Lost in Transport (Supply): %.2f MWh\n', totalSupplyLoss);
fprintf('Total Energy Lost in Storage (Injection): %.2f MWh\n', totalInjectionLoss);
fprintf('Total Energy Lost in Storage (Extraction): %.2f MWh\n', totalExtractionLoss);
fprintf('Total Energy Lost in Storage (Total): %.2f MWh\n', totalStorageLoss);

fprintf('Total Energy Lost in Transport (To Demand): %.10f MWh\n', totalDeliveryLoss);
fprintf('Total Energy Loss Overall: %.2f MWh\n', totalLoss);



% Monthly sold energy aggregation
monthlySoldEnergy = zeros(length(uniqueMonths), 1);
for i = 1:length(uniqueMonths)
    % Find indices for the current month
    monthIndices = find(months == uniqueMonths(i));
    % Sum sold energy for those indices
    monthlySoldEnergy(i) = sum(soldEnergyLog(monthIndices));
end

figure;
bar(uniqueMonths + 1, monthlySoldEnergy, 'FaceColor', [0.9 0.3 0.3]);
xlabel('Month');
ylabel('Energy Sold to Grid (MWh)');
title('Monthly Energy Sold to Grid');
grid on;



% Total demand energy
totalDemandEnergy = sum(DemandpowerMW) * dt;  % MWh

% Total energy delivered directly from supply (without needing storage)
deliveredFromSupply = zeros(length(Demandtime), 1);
for t = 1:length(Demandtime)
    supplyPower = SupplypowerMW(t);
    demandPower = DemandpowerMW(t);
    directDelivery = min(supplyPower, demandPower);  % what's immediately usable
    deliveredFromSupply(t) = directDelivery * dt;
end

% Total energy used to meet demand
totalDeliveredToDemand = sum(deliveredFromSupply) + totalExtracted;

% Coverage
coveragePercentage = 100 * totalDeliveredToDemand / totalDemandEnergy;

fprintf('--- Demand Coverage Summary ---\n');
fprintf('Total Demand Energy: %.2f MWh\n', totalDemandEnergy);
fprintf('Total Direct Supply Used: %.2f MWh\n', sum(deliveredFromSupply));
fprintf('Total from Storage: %.2f MWh\n', totalExtracted);
fprintf('Total Demand Met: %.2f MWh\n', totalDeliveredToDemand);
fprintf('Percentage of Demand Covered: %.2f%%\n', coveragePercentage);

%% Helper functions

function [powerOut, powerLoss] = transport_from_supply(powerIn)
    % Parameters for copper wire
    cableLength = 1000; % meters
    voltage = 11000;    % volts 
    crossSectionArea = 4e-6; % m^2 
    resistivity = 1.724e-8; 

    % Resistance
    resistance = resistivity * cableLength / crossSectionArea;

    % From Power = Voltage * Current
    current = powerIn * 1e6 / voltage; % convert MW to W, then I = P/V

    % Power loss in W
    powerLoss = (current^2) * resistance;

    % Convert to MW and compute delivered power
    powerLoss = powerLoss / 1e6; % W to MW
    powerOut = max(0, powerIn - powerLoss);
end



function energyStored = injection(powerMW, dt)
    injectEff = 0.95;
    energyStored = max(0, powerMW) * dt * injectEff;
end

function [injectFlags, extractFlags] = multi_controller(storageStates, storageCapacities, deliveredPower, demandPower)
    % storageStates and storageCapacities are 1 x containersPerUnit vectors (for 1 unit)
    containersPerUnit = length(storageStates);
    injectFlags = false(1, containersPerUnit);
    extractFlags = false(1, containersPerUnit);

    excessPower = deliveredPower - demandPower;
    shortfallPower = demandPower - deliveredPower;

    if excessPower > 0
        for j = 1:containersPerUnit
            if storageStates(j) < storageCapacities(j)
                injectFlags(j) = true;
            end
        end
    end

    if shortfallPower > 0
        for j = 1:containersPerUnit
            if storageStates(j) > 0
                extractFlags(j) = true;
            end
        end
    end
end




function energyOut = extraction(powerMW, dt)
    extractEff = 0.95;
    energyOut = powerMW * dt * extractEff;
end

function newStorage = storage(current, injected, extracted, maxCapacity)
    newStorage = current + injected - extracted;
    newStorage = min(max(newStorage, 0), maxCapacity);
end

function [deliveredEnergy, deliveryLoss] = transport_to_demand(energyIn)
    % Same parameters as we are using same copper wire
    cableLength = 1000;           % meters
    voltage = 11000;               % volts
    crossSectionArea = 4e-6;     % m^2 
    resistivity = 1.724e-8;        

    % Resistance calculation
    resistance = resistivity * cableLength / crossSectionArea;

    % Current calculation: Power = Voltage * Current → I = P / V
    current = energyIn * 1e6 / voltage; % convert MW to W, get current in A

    % Power loss = I² * R
    deliveryLoss = (current^2) * resistance;

    % Convert to MW
    deliveryLoss = deliveryLoss / 1e6;

    % Delivered energy in MW
    deliveredEnergy = max(0, energyIn - deliveryLoss);
end