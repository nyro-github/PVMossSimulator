% Constants
time_step_sec = 900;  % 15 minutes
intervals_per_day = 24 * 3600 / time_step_sec;  % 96 intervals per day
days_per_year = 365;
total_days = 5 * days_per_year;  % exactly 5 years
total_intervals = intervals_per_day * total_days;

time_seconds = 0:time_step_sec:(total_intervals - 1) * time_step_sec;
time_hours = mod(time_seconds, 86400) / 3600;
day_of_year = mod(floor(time_seconds / 86400), 365);

year_index = floor(((0:total_intervals - 1) / intervals_per_day) / days_per_year) + 1;  % 1 to 5

% Initialize output cells
supply_rows = ["time [s], power [kW]"];
demand_rows = ["time [s], power [kW]"];

% === Function: Get sunrise/sunset based on day ===
function [sunrise, sunset] = get_sun_times(day)
    if day <= 79  % Winter (Jan 1 – Mar 20)
        sunrise = 8;
        sunset = 16;
    elseif day <= 171  % Spring (Mar 21 – Jun 20)
        sunrise = 6.5;
        sunset = 18.5;
    elseif day <= 263  % Summer (Jun 21 – Sep 20)
        sunrise = 5;
        sunset = 20;
    else  % Autumn (Sep 21 – Dec 31)
        sunrise = 7;
        sunset = 17.5;
    end
end

function p = solar_power(hour, day)
    [sunrise, sunset] = get_sun_times(day);
    if hour >= sunrise && hour <= sunset
        daylight_duration = sunset - sunrise;
        
        % Seasonal peak irradiance (W/m²), peak around summer solstice
        peak_irradiance = 900 + 100 * cos(2 * pi * (day - 172) / 365);
        I = peak_irradiance * sin(pi * (hour - sunrise) / daylight_duration);


        % Convert to power on window (kW)
        window_area = 15929;  % m²
        cloud_factor = 0.7 + 0.3 * rand();  % Simulate partial cloudiness
        I = I * cloud_factor;
        angle_correction_factor = 0.5;  % Orientation of the window
        I = I * angle_correction_factor;
        p = round((I * window_area) / 1000, 6);  % Convert W → kW
    else
        p = 0.0;
    end
end


function p = demand_power(hour, day)
    scale = 1.0;
    if day >= 150 && day <= 240
        scale = 0.4;  % Summer break
    end

    base = 0;
    if hour < 6
        base = 0.6;
    elseif hour < 9
        base = 0.6 + (2.0 - 0.6) * (hour - 6) / 3;
    elseif hour < 16
        base = 2.3;
    elseif hour < 20
        base = 2.3 - (2.3 - 0.8) * (hour - 16) / 4;
    else
        base = 0.8;
    end

    % Scale to match 6 GWh/year
    scaling_factor = 600; 
    p = round(scale * base * scaling_factor, 6);
end

% Energy tracking arrays
yearly_supply = zeros(1, 5);  % kWh
yearly_demand = zeros(1, 5);  % kWh

for i = 1:length(time_seconds)
    t = time_seconds(i);
    h = time_hours(i);
    d = day_of_year(i);
    y = year_index(i);  % now always between 1 and 5

    s = solar_power(h, d);
    dem = demand_power(h, d);

    interval_hours = time_step_sec / 3600;
    yearly_supply(y) = yearly_supply(y) + s * interval_hours;
    yearly_demand(y) = yearly_demand(y) + dem * interval_hours;

    supply_rows(end+1) = sprintf('%d, %.6f', t, s);
    demand_rows(end+1) = sprintf('%d, %.6f', t, dem);
end


fprintf('=== Yearly Energy Summary ===\n');
for y = 1:5
    fprintf('Year %d: Supply = %.2f MWh, Demand = %.2f MWh\n', ...
        y, yearly_supply(y)/1000, yearly_demand(y)/1000);
end


% === Write to Files ===
writelines(supply_rows, 'Group10_supply_5years_irradiance.csv');
writelines(demand_rows, 'Group10_demand_5years_irradiance.csv');